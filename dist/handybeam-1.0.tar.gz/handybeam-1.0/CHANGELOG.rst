:code:`CHANGELOG.rst` file.

=========
Changelog
=========

This is a pre-alpha.


Nothing to write here yet.

`https://hynek.me/articles/sharing-your-labor-of-love-pypi-quick-and-dirty/`_ told me I need this file.



