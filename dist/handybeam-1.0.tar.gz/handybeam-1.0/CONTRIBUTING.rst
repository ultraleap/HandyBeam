:code:`CONTRIBUTING.rst` file.

`https://hynek.me/articles/sharing-your-labor-of-love-pypi-quick-and-dirty/`_ tells me I need one.

This is a pre-alpha. Nothing to write here yet.

